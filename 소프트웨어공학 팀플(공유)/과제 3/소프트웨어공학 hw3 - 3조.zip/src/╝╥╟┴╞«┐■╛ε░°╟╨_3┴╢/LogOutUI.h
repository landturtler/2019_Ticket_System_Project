#include <iostream>
#include <fstream>
#pragma once
#include <string>
#include "LogOut.h"
using namespace std;

//class : LogOutUI
//description : �α׾ƿ�UI
//created : 2019/06/03 1:21am
// Author : ������

class LogOutUI{
private:
	
public:

	void clickLogOutButton(ifstream &in_fp,ofstream &out_fp,LogOut &logOut);


};
#pragma once
#include <iostream>
#include <string>
using namespace std;
#include "Member.h"
#include "MemberManager.h"
//class : LogIn
//description : �α��ν����ϴ� �Լ�
//created : 2019/06/03 1:21am
// Author : ������
class LogIn{
private:

public:
	bool showLogIn(string inputID, string inputPassword);

};
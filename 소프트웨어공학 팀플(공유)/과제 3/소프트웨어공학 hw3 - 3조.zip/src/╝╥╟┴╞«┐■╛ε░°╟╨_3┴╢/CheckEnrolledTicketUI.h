#pragma once
#include <iostream>

using namespace std;
// Class : CheckEnrolledTicketUI
// Description : CheckEnrolledTicket boundary Ŭ����
// Created : 2019/06/03 23:02pm
// Author : ������
//
// Revision :
//	     1. When & Who : 
//         What : 
class CheckEnrolledTicketUI {
public:
	void startCheckEnrolledTicket(ifstream&, ofstream &);
};
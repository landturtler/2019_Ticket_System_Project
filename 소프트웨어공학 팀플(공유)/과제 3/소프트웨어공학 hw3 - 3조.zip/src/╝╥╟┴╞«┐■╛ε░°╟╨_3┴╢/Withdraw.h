#pragma once
#include <iostream>
#include <fstream>
#include <string>
using namespace std;
#include "Member.h"
#include "MemberManager.h"
#include "TicketManager.h"
#include <vector>
using namespace std;

//class : Withdraw
//description : ȸ��Ż�� 
//created : 2019/06/03 1:21am
// Author : ������

class Withdraw{

public:
	
	string showWithdrawal();

	
};

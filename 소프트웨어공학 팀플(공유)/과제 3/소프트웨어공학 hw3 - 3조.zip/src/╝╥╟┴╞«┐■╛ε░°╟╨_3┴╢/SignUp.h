#pragma once
#include <iostream>
#include <string>
#include "MemberManager.h"
using namespace std;

// Class : SignUp
// Description : SignUp ControlŬ����
// Created : 2019/06/03 02:11pm
// Author : ������
//
// Revision :
//	     1. When & Who : 
//         What : 

class SignUp {
public:
	void showSignUp(string savedID, string savedPassword, string name, int identityNumber, int userType);
};